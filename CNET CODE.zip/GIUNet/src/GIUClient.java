import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.util.Arrays;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

public class GIUClient {

    static final int PORT = 5040;
    static final String LEADER_ID = "19005040";
    static final int DIGIT_SUM = 7;
    static final String SERVER_IP = "10.90.184.210";

    static volatile boolean running = true;
    static BlockingQueue<Integer> ackQueue = new LinkedBlockingQueue<>();
    static DatagramSocket socket;
    static InetAddress serverAddr;

    static byte[] buildPacket(int seq, String payload) throws Exception {
        byte[] payloadBytes = payload.getBytes("UTF-8");
        byte[] packet = new byte[2 + payloadBytes.length];
        packet[0] = (byte)((seq >> 8) & 0xFF);
        packet[1] = (byte)(seq & 0xFF);
        System.arraycopy(payloadBytes, 0, packet, 2, payloadBytes.length);
        return packet;
    }

    static int readSeq(byte[] data) {
        return (Byte.toUnsignedInt(data[0]) << 8) | Byte.toUnsignedInt(data[1]);
    }

    static String readPayload(byte[] data, int length) throws Exception {
        return new String(data, 2, length - 2, "UTF-8");
    }

    static void sendPacket(int seq, String payload) throws Exception {
        byte[] data = buildPacket(seq, payload);
        DatagramPacket pkt = new DatagramPacket(data, data.length, serverAddr, PORT);
        socket.send(pkt);
        GIULogger.log("SEND", data, System.currentTimeMillis());
    }

    static void sendWithACK(int seq, String payload) throws Exception {
        byte[] data = buildPacket(seq, payload);
        DatagramPacket pkt = new DatagramPacket(data, data.length, serverAddr, PORT);
        for (int attempt = 0; attempt < 2; attempt++) {
            socket.send(pkt);
            GIULogger.log("SEND", data, System.currentTimeMillis());
            Integer ack = ackQueue.poll(3, TimeUnit.SECONDS);
            if (ack != null && ack == seq) return;
            if (attempt == 0) System.out.println("[TIMEOUT] Retrying...");
        }
        System.out.println("[CONNECTION LOST]");
        running = false;
        socket.close();
        System.exit(0);
    }

    static void doHandshake() throws Exception {
        String hello = "HELLO-GIU-" + LEADER_ID + "-" + DIGIT_SUM;
        sendPacket(0, hello);
        System.out.println("[CLIENT] HELLO sent: " + hello);
        byte[] buf = new byte[1024];
        DatagramPacket reply = new DatagramPacket(buf, buf.length);
        socket.receive(reply);
        GIULogger.log("RECV", Arrays.copyOf(reply.getData(), reply.getLength()), System.currentTimeMillis());
        String response = readPayload(reply.getData(), reply.getLength());
        System.out.println("[CLIENT] Server replied: " + response);
        if (response.equals("REJECTED")) {
            System.out.println("[CLIENT] Connection rejected. Check your constants.");
            socket.close();
            System.exit(0);
        }
        String expectedOK = "OK-GIU-" + LEADER_ID + "-" + DIGIT_SUM;
        if (!response.equals(expectedOK)) {
            System.out.println("[CLIENT] Unexpected reply: " + response);
            socket.close();
            System.exit(0);
        }
        System.out.println("[CLIENT] Handshake complete.");
        System.out.println("[CLIENT] Connected! Type messages or EXIT.");
    }

    static Thread startReceiverThread() {
        Thread t = new Thread(() -> {
            byte[] buf = new byte[65535];
            while (running) {
                try {
                    DatagramPacket pkt = new DatagramPacket(buf, buf.length);
                    socket.receive(pkt);
                    byte[] raw = Arrays.copyOf(pkt.getData(), pkt.getLength());
                    GIULogger.log("RECV", raw, System.currentTimeMillis());
                    String payload = readPayload(pkt.getData(), pkt.getLength());
                    if (payload.startsWith("ACK:")) {
                        int ackSeq = Integer.parseInt(payload.substring(4));
                        ackQueue.put(ackSeq);
                    } else if (payload.equals("EXIT")) {
                        System.out.println("[Connection closed by remote.]");
                        running = false;
                        socket.close();
                        System.exit(0);
                    } else {
                        int seq = readSeq(pkt.getData());
                        System.out.println("[RECEIVED] " + payload);
                        sendPacket(0, "ACK:" + seq);
                    }
                } catch (Exception e) {
                    if (running) e.printStackTrace();
                }
            }
        });
        t.setDaemon(true);
        t.start();
        return t;
    }

    public static void main(String[] args) throws Exception {
        System.out.println("[CLIENT] Type CONNECT to open a connection.");
        java.util.Scanner sc = new java.util.Scanner(System.in);
        while (true) {
            String input = sc.nextLine().trim();
            if (input.equals("CONNECT")) break;
            System.out.println("[CLIENT] Type CONNECT to start.");
        }
        serverAddr = InetAddress.getByName(SERVER_IP);
        socket = new DatagramSocket();
        doHandshake();
        startReceiverThread();
        int seq = 1;
        while (running) {
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;
            if (line.equals("EXIT")) {
                sendPacket(0, "EXIT");
                System.out.println("[CLIENT] Closing connection.");
                socket.close();
                break;
            }
            sendWithACK(seq, line);
            seq++;
        }
    }
}