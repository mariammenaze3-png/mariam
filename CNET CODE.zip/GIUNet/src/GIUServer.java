import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.io.IOException;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class GIUServer {

    static final int    PORT      = 5040;
    static final String LEADER_ID = "19005040";
    static final int    DIGIT_SUM = 7;

    static volatile boolean running = true;
    static BlockingQueue<Integer> ackQueue = new LinkedBlockingQueue<>();
    static DatagramSocket socket;
    static InetAddress    clientAddr;
    static int            clientPort;

    static byte[] buildPacket(int seq, String payload) throws Exception {
        byte[] payloadBytes = payload.getBytes("UTF-8");
        byte[] packet = new byte[2 + payloadBytes.length];
        packet[0] = (byte)((seq >> 8) & 0xFF);
        packet[1] = (byte)(seq & 0xFF);
        System.arraycopy(payloadBytes, 0, packet, 2, payloadBytes.length);
        return packet;
    }

    static int readSeq(byte[] data) {
        return (Byte.toUnsignedInt(data[0]) << 8)
             |  Byte.toUnsignedInt(data[1]);
    }

    static String readPayload(byte[] data, int length) throws Exception {
        return new String(data, 2, length - 2, "UTF-8");
    }


    static void sendPacket(int seq, String payload) throws Exception {
        byte[] data = buildPacket(seq, payload);
        DatagramPacket pkt = new DatagramPacket(
            data, data.length, clientAddr, clientPort);
        socket.send(pkt);
        GIULogger.log("SEND", data, System.currentTimeMillis());
    }

    static void sendWithACK(int seq, String payload) throws Exception {
        byte[] data = buildPacket(seq, payload);
        DatagramPacket pkt = new DatagramPacket(
            data, data.length, clientAddr, clientPort);

        for (int attempt = 0; attempt < 2; attempt++) {
            socket.send(pkt);
            GIULogger.log("SEND", data, System.currentTimeMillis());

            Integer ack = ackQueue.poll(3, java.util.concurrent.TimeUnit.SECONDS);
            if (ack != null && ack == seq) return;

            if (attempt == 0)
                System.out.println("[TIMEOUT] Retrying...");
        }

        System.out.println("[CONNECTION LOST]");
        running = false;
        socket.close();
        System.exit(0);
    }


    static void waitForHandshake() throws Exception {
        System.out.println("[SERVER] Listening on port " + PORT);
        System.out.println("[SERVER] Waiting for connection...");

        byte[] buf = new byte[1024];
        DatagramPacket pkt = new DatagramPacket(buf, buf.length);
        socket.receive(pkt);

        clientAddr = pkt.getAddress();
        clientPort = pkt.getPort();

        String payload = readPayload(pkt.getData(), pkt.getLength());
        System.out.println("[SERVER] Received: " + payload);
        GIULogger.log("RECV", pkt.getData(), System.currentTimeMillis());

        String expected = "HELLO-GIU-" + LEADER_ID + "-" + DIGIT_SUM;

        if (!payload.equals(expected)) {
            sendPacket(0, "REJECTED");
            System.out.println("[SERVER] Handshake REJECTED.");
            socket.close();
            System.exit(0);
        }

        sendPacket(0, "OK-GIU-" + LEADER_ID + "-" + DIGIT_SUM);
        System.out.println("[SERVER] Handshake complete.");
        System.out.println("[SERVER] Connection established!");
    }


    static Thread startReceiverThread() {
        Thread t = new Thread(() -> {
            byte[] buf = new byte[65535];
            while (running) {
                try {
                    DatagramPacket pkt = new DatagramPacket(buf, buf.length);
                    socket.receive(pkt);
                    GIULogger.log("RECV",
                        java.util.Arrays.copyOf(pkt.getData(), pkt.getLength()),
                        System.currentTimeMillis());

                    String payload = readPayload(pkt.getData(), pkt.getLength());

                    if (payload.startsWith("ACK:")) {
                        int seq = Integer.parseInt(payload.substring(4));
                        ackQueue.put(seq);

                    } else if (payload.equals("EXIT")) {
                        System.out.println("[Connection closed by remote.]");
                        running = false;
                        socket.close();
                        System.exit(0);

                    } else {
                        int seq = readSeq(pkt.getData());
                        System.out.println("[RECEIVED] " + payload);
                        sendPacket(0, "ACK:" + seq);
                    }

                } catch (Exception e) {
                    if (running) e.printStackTrace();
                }
            }
        });
        t.setDaemon(true);
        t.start();
        return t;
    }


    public static void main(String[] args) throws Exception {
        socket = new DatagramSocket(5040);
        waitForHandshake();
        startReceiverThread();

        java.util.Scanner sc = new java.util.Scanner(System.in);
        int seq = 1;

        while (running) {
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;

            if (line.equals("EXIT")) {
                sendPacket(0, "EXIT");
                System.out.println("[SERVER] Closing connection.");
                socket.close();
                break;
            }

            sendWithACK(seq, line);
            seq++;
        }
    }
}